document.addEventListener('DOMContentLoaded', () => {
 const textoBusquedaElement = document.getElementById('Buscador');
  let orden = "";
  let modeloSeleccionado = "";
 
  document.getElementById('Mayor').addEventListener('click', () => {
    orden = "Mayor";
  });

  document.getElementById('Menor').addEventListener('click', () => {
    orden = "Menor";
  });

  const modelos = document.querySelectorAll(".modelo");
  modelos.forEach(modelo => {
    modelo.addEventListener('click', () => {
      modeloSeleccionado = modelo.dataset.modelo;
    });
  });

  function ObtenerFiltros() {
    // Obtener el valor de los checkboxes
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    const categoria = [];
    const color = [];
    const genero = [];
    checkboxes.forEach(checkbox => {
      if (checkbox.checked) {
        if (checkbox.hasAttribute('data-categoria')) {
          categoria.push(checkbox.value);
        }
        if (checkbox.hasAttribute('data-color')) {
          color.push(checkbox.value);
        }
        if (checkbox.hasAttribute('data-genero')) {
          genero.push(checkbox.value);
        }
      }
    });

    // DEBUG: Imprimir valores antes de construir URL
    console.log("Categoría:", categoria);
    console.log("Color:", color);
    console.log("Género:", genero);
    console.log("Modelo seleccionado:", modeloSeleccionado);
    console.log("Orden:", orden);

    const textoBusqueda = textoBusquedaElement ? textoBusquedaElement.value : "";
    console.log("Texto de búsqueda:", textoBusqueda);
    let url = `productos.html?categoria=${categoria.join(',')}&orden=${orden}&color=${color.join(',')}&genero=${genero.join(',')}&modeloSeleccionado=${modeloSeleccionado}&textoBusqueda=${textoBusqueda}`;
    console.log("URL generada:", url);
    window.location.href = url;
    console.log('textoBusqueda:', textoBusqueda);
  };
    function MostrarProductos2(ProductosFinales){

        const productosHTML2 = ProductosFinales.map((producto) => { //Se crea otra variable que almacena los productos ya filtrados y random y hara una iteracion a cada uno con map
          return ` 
            <div class="busqueda-container"> 
            <a href="${producto.links.imagenLink1}">  <img src="${producto.imagen}" alt="${producto.nombre}"></a>
              <h3>${producto.nombre}</h3>
            </div> 
          `;
        }).join(''); //Esto es la estructura que se hara para el html y que se hara para cada producto
      const productosContenedor2 = document.getElementById('Productos2'); //Se obtiene el contenedor donde ira la estructura que acabamos de hacer 
      
        productosContenedor2.innerHTML = productosHTML2; //Se ponen los productos en el contenedor
      
      }
   const textoBusquedaElement2 = document.getElementById('Buscador'); //Se obtiene el buscador

    textoBusquedaElement2.addEventListener('input', () => { // Cada vez eu el usuario escriba en el buscador:
     
      const ListaProductos = document.getElementById('Productos2'); //Se obtiene el contenedor de los productos
      if (textoBusquedaElement2.value === '') { //Si no hay texto en el buscador entonces:
        ListaProductos.style.display = 'none'; //Oculta el contenedor de productos
        return;
      }
      if (ListaProductos) ListaProductos.style.display = 'flex'; //Si hay texto aparece el contenedor
      const texto = textoBusquedaElement2.value.toLowerCase(); //Convertimos el texto del usuario a minusculas
      
      const productosFiltrados2 = productos.filter(pe => //Filtramos
        pe.nombre.toLowerCase().includes(texto) || //Si el nombre del producto incluye algo del texto del usuario se incluira a productosFiltrados2
        pe.categoria.toLowerCase().includes(texto) ||  //Si la categoria del producto incluye algo del texto del usuario se incluira a productosFiltrados2
        pe.genero.toLowerCase().includes(texto)  //Si el genero del producto incluye algo del texto del usuario se incluira a productosFiltrados2
      );
      const ProductosAleatorios = new Set(); //Productos aleatorios se inicializan con set para evitar repetidos
      for (let i = 0; i < 3; i++){ //Bucle for solo para 3 productos
        const Indice = Math.floor(Math.random() * productosFiltrados2.length); //El indice es el que obtiene el random
        ProductosAleatorios.add(productosFiltrados2[Indice]); //Se agregan los productos randomizados a ProductosAleatorios
        
      }
      const ProductosFinales = Array.from( ProductosAleatorios); //Array de ProductosFinales obtenidos de ProductosAleatorios
      console.log(ProductosAleatorios);
      MostrarProductos2(ProductosFinales); //Se llama a la funcion MostrarProductos2
      console.log(productosFiltrados2);
    });
  
  document.getElementById('aplicar-filtros').addEventListener('click', ObtenerFiltros);
  document.getElementById('Busqueda').addEventListener('click', ObtenerFiltros);
    
});
