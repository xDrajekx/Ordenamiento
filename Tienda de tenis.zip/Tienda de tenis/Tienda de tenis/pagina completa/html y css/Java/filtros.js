document.addEventListener('DOMContentLoaded', () => {
 const textoBusquedaElement = document.getElementById('Buscador');
  let orden = "";
  let modeloSeleccionado = "";
 
  document.getElementById('Mayor').addEventListener('click', () => {
    orden = "Mayor";
  });

  document.getElementById('Menor').addEventListener('click', () => {
    orden = "Menor";
  });

  const modelos = document.querySelectorAll(".modelo");
  modelos.forEach(modelo => {
    modelo.addEventListener('click', () => {
      modeloSeleccionado = modelo.dataset.modelo;
    });
  });

  function ObtenerFiltros() {
    // Obtener el valor de los checkboxes
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    const categoria = [];
    const color = [];
    const genero = [];
    checkboxes.forEach(checkbox => {
      if (checkbox.checked) {
        if (checkbox.hasAttribute('data-categoria')) {
          categoria.push(checkbox.value);
        }
        if (checkbox.hasAttribute('data-color')) {
          color.push(checkbox.value);
        }
        if (checkbox.hasAttribute('data-genero')) {
          genero.push(checkbox.value);
        }
      }
    });

    // DEBUG: Imprimir valores antes de construir URL
    console.log("Categoría:", categoria);
    console.log("Color:", color);
    console.log("Género:", genero);
    console.log("Modelo seleccionado:", modeloSeleccionado);
    console.log("Orden:", orden);

    const textoBusqueda = textoBusquedaElement ? textoBusquedaElement.value : "";
    console.log("Texto de búsqueda:", textoBusqueda);
    let url = `productos.html?categoria=${categoria.join(',')}&orden=${orden}&color=${color.join(',')}&genero=${genero.join(',')}&modeloSeleccionado=${modeloSeleccionado}&textoBusqueda=${textoBusqueda}`;
    console.log("URL generada:", url);
    window.location.href = url;
    console.log('textoBusqueda:', textoBusqueda);
  };
  
  document.getElementById('aplicar-filtros').addEventListener('click', ObtenerFiltros);
  document.getElementById('Busqueda').addEventListener('click', ObtenerFiltros);
    
});
