document.addEventListener('DOMContentLoaded',() =>{
const urlParams = new URLSearchParams(window.location.search); //A partir de aqui se obtienen todos los parametros de la url
const categoriaParam = urlParams.get('categoria') || '';
const orden2 = urlParams.get('orden') || '';
const colorParam = urlParams.get('color') || '';
const categorias = categoriaParam ? categoriaParam.split(',') : [];
const colores = colorParam ? colorParam.split(',') : [];
const generosParam = urlParams.get('genero') || '';
console.log(categoriaParam);
const generos = generosParam ? generosParam.split(',') : [];
const textoBusqueda = urlParams.get('textoBusqueda') || '';
console.log(textoBusqueda);
const modeloSeleccionado2 = urlParams.get('modeloSeleccionado'); //aqui termina de obtener todos los parametros
const productos = [ //este es un arreglo que contiene todos los productos con sus caracteristicas, imagenes y links
  { id: 1, nombre: 'Air Force 1 07', categoria: 'Nike', precio: '2,199', color: 'Negro', genero: 'Hombre', imagen: '../Zapatos.nike/Air Force 1 07.avif', link: 'pagina completa/html y css/Tenis/Nike2.html?id=AirForce1' ,
     imagenes:{imagencolor: '../Zapatos.nike/Air Force 1 07.avif',imagencolor1:'../Colores NIke/Air force 1 07.avif', imagencolor2:'../Colores NIke/Air force 1 07 2.avif' },
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirForce1', imagenLink2: 'Tenis/Nike2.html?id=AirForce2', imagenLink3: 'Tenis/Nike2.html?id=AirForce3' } },
  { id: 2, nombre: 'Air Jordan 1', categoria: 'Nike', color: 'Verde', precio: '2,299', genero: 'Hombre', imagen: '../Zapatos.nike/AirJordan1 Low.jpg', link: 'Tenis/Nike2.html?id=AirJordan1Low',
    imagenes: {imagencolor: '../Zapatos.nike/AirJordan1 Low.jpg', imagencolor1: '../Colores Nike/Air Jordan 1 Low.avif', imagenLink2: '../Colores Nike/Air Jordan 1 Low 2.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirJordan1Low', imagenLink2: 'Tenis/Nike2.html?id=AirJordan1Low2', imagenLink3: 'Tenis/Nike2.html?id=AirJordan1Low3'}
  },
 
  { id: 3, nombre: 'Nike AirMax90', categoria: 'Nike', color: 'Negro', precio: '$1,750', genero: 'Hombre', imagen: '../Zapatos.nike/AirMax90.jpg' , link: "Tenis/Nike2.html?id=AirMax",
     imagenes:{imagencolor: '../Zapatos.nike/AirMax90.jpg',imagencolor1:'../Colores Nike/AirMax902.jpg', imagencolor2:'../Colores Nike/AirMax903.jpg', imagencolor3: '../Colores Nike/AirMax904.jpg', imagencolor4: '../Colores Nike/AirMax906.jpg' },
    links: {imagenLink1: "Tenis/Nike2.html?id=AirMax1" , imagenLink2: "Tenis/Nike2.html?id=AirMax2", imagenLink3: "Tenis/Nike2.html?id=AirMax3", imagenLink4: "Tenis/Nike2.html?id=AirMax4", imagenLink5: "Tenis/Nike2.html?id=AirMax5" } },

  {id: 4, nombre: 'Nike Air Max Bw', categoria: 'Nike', color: 'Negro', precio: '$$2,799', genero: 'Hombre', imagen: '../Zapatos.nike/Air Max Bw.jpg', link: 'Tenis/Nike2.html?id=AirMaxBw',
    imagenes:{imagencolor: '../Zapatos.nike/Air Max Bw.jpg', imagencolor1: '../Colores Nike/Air Max Bw 2.jpg', imagencolor2: '../Colores Nike/Air Max Bw 3.webp' },
    links: {imagenLink1:'Tenis/Nike2.html?id=AirMaxBw', imagenLink2: 'Tenis/Nike2.html?id=AirMaxBw2', imagenLink3: 'Tenis/Nike2.html?id=AirMaxbw3'}
  },
  {id: 5, nombre: 'Nike Air Max 95', categoria:'Nike', color: 'Negro', precio: '$3,700', genero: 'Mujer', imagen: '../Zapatos.nike/AirMax95.jpg', link: 'Tenis/NIke2.html?id=AirMax95',
    imagenes: {imagencolor: '../Zapatos.nike/AirMax95.jpg', imagencolor1: '../Colores Nike/Air max 95.avif', imagencolor2: '../Colores Nike/Air Max 95 2.avif' },
    links: {imagenLink1: 'Tenis/NIke2.html?id=AirMax95', imagenLink2: 'Tenis/NIke2.html?id=AirMax952', imagenLink3: 'Tenis/NIke2.html?id=AirMax953'}
  },
  {id: 7, nombre: 'Nike Air Max 97', categoria: 'Nike', color: 'Negro', precio: '$3,700', genero: 'Mujer', imagen: '../Zapatos.nike/AirMax97.jpg', link: 'Tenis/Nike2.html?id=AirMax97',
    imagenes: {imagencolor: '../Zapatos.nike/AirMax97.jpg'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirMax97'}
  },
  {id: 8, nombre: 'Nike Air Force 1 Shadow', categoria: 'Nike', color: 'Blanco', precio: '$2,800', genero: 'Mujer', imagen: '../Zapatos.nike/Air Force 1 Shadow.avif', link: 'Tenis/Nike2.html?id=AirForceShadow',
    imagenes: {imagencolor: '../Zapatos.nike/Air Force 1 Shadow.avif', imagencolor1: '../Colores Nike/Air Force 1 Shadow 2.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirForceShadow', imagenLink2: 'Tenis/Nike2.html?id=AirForceShadow2'}
  },
  {id: 9, nombre: 'Nike Air Force 1 Shadow Gundam', categoria: 'Nike', color:'Blanco', precio: '$2,900', genero: 'Mujer', imagen: '../Zapatos.nike/Air Force 1 Shadow Gundam.webp', link: 'Tenis/Nike2.html?id=AirForceGundam',
    imagenes: {imagencolor: '../Zapatos.nike/Air Force 1 Shadow Gundam.webp'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirForceGundam'}
  },
  {id: 10, nombre: 'Nike Air Force 1 Low x Ambush', categoria: 'Nike', color: 'Negro', precio: '$1,900', genero: 'Hombre', imagen: '../Zapatos.nike/Air Force 1 Low x Ambush.avif', link: 'Tenis/Nike2.html?id=AirForceAmbush',
    imagenes: {imagencolor: '../Zapatos.nike/Air Force 1 Low x Ambush.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirForceAmbush'}
  },
  {id: 11, nombre: 'Nike C1ty', categoria: 'Nike', color: 'Negro', precio: '$2,100', genero: 'Unisex', imagen: '../Zapatos.nike/Nike C1ty.avif', link: 'Tenis/Nike2.html?id=NikeC1ty',
    imagenes: {imagencolor: '../Zapatos.nike/Nike C1ty.avif', imagencolor1: '../Colores Nike/Nike C1ty 2.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=NikeC1ty', imagenLink2: 'Tenis/Nike2.html?id=NikeC1ty2'}
  },
  {id: 12, nombre: 'Nike V2K Run', categoria: 'Nike', color: 'Verde', precio: '$1,800', genero: 'Hombre', imagen: '../Zapatos.nike/Nike V2K Run.avif', link: 'Tenis/Nike2.html?id=V2KRun',
    imagenes: {imagencolor: '../Zapatos.nike/Nike V2K Run.avif', imagencolor1: '../Colores Nike/Nike V2K RUn.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=NikeV2KRun', imagenLink2: 'Tenis/Nike2.html?id=NikeV2KRun2'}
  },
  {id: 13, nombre: 'Nike Air Force 1 Halloween', categoria: 'Nike', color: 'Negro', precio: '$1,650', genero: 'Hombre', imagen: '../Zapatos.nike/Nike Air Force 1 Halloween.webp', link: 'Tenis/Nike2.html?id=AirForceHalloween',
    imagenes: {imagencolor: '../Zapatos.nike/Nike Air Force 1 Halloween.webp'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirForceHalloween'}
  },
  {id: 14, nombre: 'Nike Field General', categoria: 'Nike', color: 'Azul', precio: '$1500', genero: 'Hombre', imagen: '../zapatos.nike/Nike Field General.avif', link: 'Tenis/Nike2.html?id=FieldGeneral',
    imagenes: {imagencolor: '../zapatos.nike/Nike Field General.avif', imagencolor1: '../Colores Nike/Nike Field General 2.avif', imagencolor2: '../Colores Nike/Nike Field General 3.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=FieldGeneral', imagenLink2: 'Tenis/Nike2.html?id=FieldGeneral2', imagenLink3: 'Tenis/Nike2.html?id=FieldGeneral3'}
  },
  { id: 8, nombre: 'Nike Air Force 1 Dance', categoria: 'Nike', color: 'Negro', precio: '1499MXN',  genero: 'Mujer', imagen: '../Zapatos.nike/Air Force 1  Dance.avif', link: 'Tenis/Nike2.html?id=AirForceDance',
    imagenes:{imagencolor: '../Zapatos.nike/Air Force 1  Dance.avif', imagencolor1: '../Colores Nike/Air Force 1  Dance2.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirForceDance', imagenLink2:' Tenis/Nike2.html?id=AirForceDance2'}  },
  {id: 9, nombre: 'Nike Jordan Max Aura', categoria: 'Nike', color: 'Rojo', precio: '$2169', genero: 'Hombre', imagen: '../zapatos/Jordan Max Aura 6.avif', link: 'Tenis/Nike2.html?id=JordanMaxAura',
    imagenes: {imagencolor: '../zapatos/Jordan Max Aura 6.avif', imagencolor1: '../Colores Nike/Jordan Max Aura 6 2.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=JordanMaxAura', imagenLink2: 'Tenis/Nike2.html?id=JordanMaxAura2'}
  },
  {id: 10, nombre: 'Nike Air Jordan 3', categoria: 'Nike', color: 'Blanco', precio: '5,199', genero: 'Hombre', imagen: '../zapatos/Air Jordan 3.avif', link: 'Tenis/Nike2.html?id=AirJordan3',
    imagenes: {imagencolor: '../zapatos/Air Jordan 3.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirJordan3'}
  },
  {id: 11, nombre: 'Nike Air Jordan 6 Rings', categoria: 'Nike', color: 'Negro', precio: '$2,699', genero: 'Hombre', imagen: '../zapatos/Nike Jordan 6  Rings.avif', link: 'Tenis/Nike2.html?id=AirJordan6Rings',
    imagenes: {imagencolor: '../zapatos/Nike Jordan 6  Rings.avif', imagencolor1: '../Colores Nike/Nike Jordan 6 Rings.avif' },
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirJordan6Rings', imagenLink2: 'Tenis/Nike2.html?id=AirJordan6Rings2'}
  },
  {id: 12, nombre: 'Nike Air Jordan Mid SE', categoria: 'Nike', color: 'Morado', precio: '$3,399', genero: 'Mujer', imagen: '../zapatos/Air Jordan 1 MId SE.avif', link: 'Tenis/Nike2.html?id=AirJordanMidSE',
    imagenes: {imagencolor: '../zapatos/Air Jordan 1 MId SE.avif', imagencolor1: '../Colores Nike/img7.webp', imagencolor2: '../Colores Nike/Air Jordan 1 Mid SE.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirJordanMidSE', imagenLink2: 'Tenis/Nike2.html?id=AirJordanMidSE2', imagenLink3: 'Tenis/Nike2.html?id=AirJordanMidSE3'}
  },
  {id: 14, nombre: 'Nike Air Jordan 1 MId', categoria: 'Nike', color: 'Azul', precio: '$3,499', genero: 'Hombre', imagen: '../zapatos/Air Jordan 1 Mid.avif', link: 'Tenis/Nike2.html?id=AirJordanMid',
    imagenes: {imagencolor: '../zapatos/Air Jordan 1 MId.avif', imagencolor1: '../Colores Nike/Air Jordan 1 Mid H.avif'},
    links: {imagenLink1: 'Tenis/Nike2.html?id=AirJordanMid', imagenLink2: 'Tenis/Nike2.html?id=AirJordanMid2'}
  },
  
  { id: 13, nombre: 'Adidas Campus 00s', categoria: 'Adidas', color: 'Negro', precio: '$1,699', genero: 'Unisex', imagen: '../Apartado adidas/images/Adidas Campus 00s.jpg', link: "Tenis/Nike2.html?id=Campus",
    imagenes: {imagencolor: '../Apartado adidas/images/Adidas Campus 00s.jpg', imagencolor1:  '../Apartado adidas/Imagenes de colores/Adidas Campus 00s 2.avif', imagencolor2:  '../Apartado adidas/Imagenes de colores/Adidas Campus 00s 3.avif'},
    links: { imagenLink1: 'Tenis/Nike2.html?id=Campus', imagenLink2: 'Tenis/Nike2.html?id=Campus2', imagenLink3: 'Tenis/Nike2.html?id=Campus3'}},

  { id: 16, nombre: 'Adidas superstar', categoria: 'Adidas', color:'Negro', precio: '1,799',  genero: 'Unisex', imagen:'../Apartado adidas/images/Adidas superstar.jpg', link: 'Tenis/nike2.html?id=Superstar',
    imagenes: {imagencolor:'../Apartado adidas/images/Adidas superstar.jpg', imagencolor1: '../Apartado adidas/Imagenes de colores/Adidas superstar 2.jpg' },
    links: {imagenLink1: 'Tenis/nike2.html?id=Superstar', imagenLink2: 'Tenis/nike2.html?id=Superstar2'}},
  
  {id: 18, nombre: 'Adidas Forum Low CL', categoria: 'Adidas', color:'Blanco', precio: '$2,299', genero:'Hombre', imagen:'../Apartado adidas/images/Adidas Forum Low CL.avif', link: "Tenis/Nike2.html?id=ForumLow",
    imagenes:{imagencolor: '../Apartado adidas/images/Adidas Forum Low CL.avif', imagencolor2:'../Apartado adidas/Imagenes de colores/Adidas Forum Cl 2.avif',imagencolor3:'../Apartado adidas/Imagenes de colores/Adidas Forum Low CL 3.avif' },
    links: {imagenLink1: "Tenis/Nike2.html?id=ForumLow", imagenLink2: "Tenis/Nike2.html?id=ForumLow2", imagenLink3: "Tenis/Nike2.html?id=ForumLow3"}
   },

   {id: 21, nombre: 'Adizero Adios PRO 4', categoria: 'Adidas', color: 'Rojo', precio: '$4,999', genero: 'Mujer', imagen: '../Apartado adidas/images/Adizero Adios PRO 4.avif', link: 'Tenis/Nike2.html?id=Adizero',
    imagenes:{imagencolor: '../Apartado adidas/images/Adizero Adios PRO 4.avif', imagencolor1: '../Apartado adidas/Imagenes de colores/Adizero Adios PRO 4 2.avif', imagencolor2: '../Apartado adidas/Imagenes de colores/Adizero Adios PRO 4 3.avif', imagencolor3: '../Apartado adidas/images/teni12.jpg'},
    links:{imagenLink1:'Tenis/Nike2.html?id=Adizero', imagenLink2: 'Tenis/Nike2.html?id=Adizero2', imagenLink3: 'Tenis/Nike2.html?id=Adizero3', imagenLink4: 'Tenis/Nike2.html?id=Adizero4'}
   },

   {id: 24, nombre: 'Adidas Gazelle', categoria: 'Adidas', color: 'Rojo', precio: '$2,399', genero: 'Mujer', imagen: '../Apartado adidas/images/Adidas Gazelle.avif', link: 'Tenis/Nike2.html?id=Gazelle',
    imagenes:{imagencolor: '../Apartado adidas/images/Adidas Gazelle.avif', imagencolor1: '../Apartado adidas/Imagenes de colores/Adidas Gazelle 2.avif', imagencolor2: '../Apartado adidas/Imagenes de colores/Adidas Gazelle 3.avif', imagencolor3: '../Apartado adidas/Imagenes de colores/Adidas Gazelle 4.avif'},
    links: {imagenLink1:'Tenis/Nike2.html?id=Gazelle', imagenLink2: 'Tenis/Nike2.html?id=Gazelle2', imagenLink3: 'Tenis/Nike2.html?id=Gazelle3', imagenLink4: 'Tenis/Nike2.html?id=Gazelle4'}
   },

   {id: 28, nombre: 'Adidas Samba x Toy Story', categoria: 'Adidas', color: 'Cafe', precio: '$1,899', genero:'Niños', imagen: '../Apartado adidas/images/teni6.jpg', link: 'Tenis/Nike2.html?id=SambaToyStory',
   imagenes: {imagencolor:'../Apartado adidas/images/teni6.jpg'},
   links: {imagenLink1: 'tenis/Nike2.html?id=SambaToyStory'}
   },
   {id:29, nombre:  'Adidas Orginals x Bad Bunny',categoria: 'Adidas', color: 'Blanco', precio:'$2,099', genero: 'Hombre', imagen:'../Apartado adidas/images/teni7.jpg', link: 'Tenis/Nike2.html?id=OriginalsBadBunny',
    imagenes:{imagencolor: '../Apartado adidas/images/teni7.jpg' },
    links:{imagenLink1: 'Tenis/Nike2.html?id=OriginalsBadBunny'}
   },
   {id: 30, nombre: 'Adidas Italia x CP Company', categoria: 'Adidas', color: 'Azul', precio: '$2,299', genero: 'Hombre', imagen: '../Apartado adidas/images/teni8.jpg', link: 'Tenis/Nike2.html?id=Italia',
    imagenes:{imagencolor: '../Apartado adidas/images/teni8.jpg'},
    links:{imagenLink1: 'Tenis/Nike2.html?id=Italia'}
   },
   {id: 31, nombre: 'Adidas Handball Spezial', categoria: 'Adidas', color: 'Rojo', precio: '$2,199', genero: 'Hombre', imagen: '../Apartado adidas/images/Adidas Handball Spezial.avif', link: 'Tenis/Nike2.html?id=Handball',
    imagenes:{imagencolor: '../Apartado adidas/images/Adidas Handball Spezial.avif', imagencolor1: '../Apartado adidas/Imagenes de colores/Adidas Handball Spezial 2.avif', imagencolor2: '../Apartado adidas/Imagenes de colores/Adidas Handball Spezial 3.avif'},
    links:{imagenLink1: 'Tenis/Nike2.html?id=Handball', imagenLink2: 'Tenis/Nike2.html?id=Handball2', imagenLink3: 'Tenis/Nike2.html?id=Handball3'} 
   },
   {id: 32, nombre: 'Adidas Geodiver Primeblue', categoria: 'Adidas', color: 'Azul', precio: '$1,750', genero: 'Hombre', imagen: '../Apartado adidas/Images/Adidas Geodiver Primeblue 2.jpg', link: 'Tenis/Nike2.html?id=Geodiver',
    imagenes:{imagencolor: '../Apartado adidas/Images/Adidas Geodiver Primeblue 2.jpg',  },
    links:{imagenLink1: 'Tenis/Nike2.html?id=Geodiver', imagenLink2: 'Tenis/Nike2.html?id=Geodiver2'}
   },
   
]; //Aqui termina el arreglo de los productos
function AplicarFiltros(){
  // Obtener SIEMPRE el valor actual del input de búsqueda
  
  const BusquedaCorregida = textoBusqueda.toLowerCase();
  let productosFiltrados = productos.filter(pe =>
    (categorias.length === 0 || categorias.includes(pe.categoria)) &&
    (colores.length === 0 || colores.includes(pe.color)) &&
    (generos.length === 0 || generos.includes(pe.genero)) &&
    (modeloSeleccionado2 === '' || pe.nombre === modeloSeleccionado2) &&
    (
      BusquedaCorregida === '' ||
      pe.nombre.toLowerCase().includes(BusquedaCorregida) ||
      pe.categoria.toLowerCase().includes(BusquedaCorregida) ||
      pe.genero.toLowerCase().includes(BusquedaCorregida)
    )
  );
//A la variable productosFiltrados se le asigna el arreglo de productos si las condiciones son de 0, o si una variable contiene un valor  igual a  categorias, color o miodeloseleccionado
if (orden2 === 'Mayor') { //Si la variable orden2 es igual a Mayor entonces:
  productosFiltrados.sort((a, b) => b.precio - a.precio); //Ordenara el precio de mayor a menor
} else if (orden2 === 'Menor') { //Pero si la variable orden2 es igual a Menor entonces:
  productosFiltrados.sort((a, b) => a.precio - b.precio); //Ordenara el precio de menor a mayor
}
MostrarProductos(productosFiltrados)

}
    function MostrarProductos(productosFiltrados){
  const productosHTML = productosFiltrados.map((producto) => { //Se crea otra variable que almacena los productos ya filtrados y hara una iteracion a cada uno con map
    return ` 
      <div class="imagen-container"> 
        <img src="${producto.imagen}" alt="${producto.nombre}" class="evento2">
        <div class="imagenes-ocultas Evento2">
       ${producto.links?.imagenLink1 && producto.imagenes?.imagencolor ?` <a href = "${producto.links.imagenLink1}">   <img src="${producto.imagenes.imagencolor}" alt="${producto.nombre}"> </a> `: ""}
          ${producto.links?.imagenLink2  && producto.imagenes?.imagencolor1 ?` <a href = "${producto.links.imagenLink2}">   <img src="${producto.imagenes.imagencolor1}" alt="${producto.nombre}"> </a> `: ""}
          ${producto.links?.imagenLink3  && producto.imagenes?.imagencolor2 ?` <a href = "${producto.links.imagenLink3}" >   <img src="${producto.imagenes.imagencolor2}" alt="${producto.nombre}"> </a> `: ""}
          ${producto.links?.imagenLink4  && producto.imagenes?.imagencolor3 ?` <a href = "${producto.links.imagenLink4}" >   <img src="${producto.imagenes.imagencolor3}" alt="${producto.nombre}"> </a> `: ""}
          ${producto.links?.imagenLink5  && producto.imagenes?.imagencolor4 ?` <a href = "${producto.links.imagenLink5}" >   <img src="${producto.imagenes.imagencolor4}" alt="${producto.nombre}"> </a> `: ""}
        </div>
        <h3>${producto.nombre}</h3>
        <p class="precio">Precio: ${producto.precio}</p>
        <button class="B1">  <a href="${producto.link}"><span class="B2">Ver más</span></a></button>
      </div>
    `;
  }).join(''); //La ieracion map en cada uno de los productos sera hacer esta estructura html a cada uno en la que los valores seran las propiedades de los productos filtrados
  
  const productosContenedor = document.getElementById('productos'); //Se obtiene el contenedor en donde se ingresaran los productos con la estructura
productosContenedor.innerHTML = productosHTML; //Se ingresan los productos dentro del contenedor
    }
      AplicarFiltros();
      function MostrarProductos2(productosFiltrados2){
        let productosHTML2 = '';
  if (productosFiltrados2.length === 0) {
    productosHTML2 = '<div class="busqueda-container"><p>No se encontraron resultados.</p></div>';
  } else {
    productosHTML2 = productosFiltrados2.map((producto) => {
      return ` 
        <div class="busqueda-container"> 
          <img src="${producto.imagen}" alt="${producto.nombre}" >
          <h3>${producto.nombre}</h3>
        </div>
      `;
    }).join('');
  }
  const productosContenedor2 = document.getElementById('Productos2');
  productosContenedor2 ?
    productosContenedor2.innerHTML = productosHTML2 :
    console.warn('No se encontró el contenedor Productos2');
      
      }
      
      const textoBusquedaElement2 = document.getElementById('Buscador');
      function normalizarTexto(texto) {
        return texto
          .toLowerCase()
          .normalize('NFD')
          .replace(/[\u0300-\u036f]/g, '') // quita acentos
          .replace(/\s+/g, ''); // quita espacios
      }
      textoBusquedaElement2 ? 
        textoBusquedaElement2.addEventListener('keyup', () => {
          const ListaProductos = document.getElementById('Productos2');
          ListaProductos.style.display = 'block';
          const texto = normalizarTexto(textoBusquedaElement2.value);
          const productosFiltrados2 = productos.filter(pe =>
            normalizarTexto(pe.nombre).includes(texto) ||
            normalizarTexto(pe.categoria).includes(texto) ||
            normalizarTexto(pe.genero).includes(texto)
          );
          MostrarProductos2(productosFiltrados2);
        }) : console.warn('No se encontró el input Buscador');
      

});
// Aqui termina el script de los filtros